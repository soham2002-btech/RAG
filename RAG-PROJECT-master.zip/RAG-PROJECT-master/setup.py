from setuptools import find_packages, setup

setup(
    name = 'QApplication',
    version= '0.0.1',
    author= 'Alok kumar',
    author_email= 'ay747283@gmail.com',
    packages= find_packages(),
    install_requires = []

)